/*
 * @Author: 王琨
 * @Date: 2021-10-21 10:34:58
 * @Descripttion:
 */
var config = {
    mode: "fixed_servers",
    rules: {
      singleProxy: {
        scheme: "http",
        host: "140.143.62.84",
        port: 19480
      },
      bypassList: ["mimvp.com"]
    }
  };

chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

function callbackFn(details) {
    return {
        authCredentials: {
            username: "mimvp-user",
            password: "mimvp-pass"
        }
    };
}

chrome.webRequest.onAuthRequired.addListener(
        callbackFn,
        {urls: ["<all_urls>"]},
        ['blocking']
);
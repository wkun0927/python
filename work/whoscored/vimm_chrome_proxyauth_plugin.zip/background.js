
    var config = {
            mode: "fixed_servers",
            rules: {
              singleProxy: {
                scheme: "https",
                host: "proxy.crawlera.com",
                port: parseInt(8010)
              },
              bypassList: ["foobar.com"]
            }
          };

    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

    function callbackFn(details) {
        return {
            authCredentials: {
                username: "fea687a8b2d448d5a5925ef1dca2ebe9",
                password: ""
            }
        };
    }

    chrome.webRequest.onAuthRequired.addListener(
                callbackFn,
                {urls: ["<all_urls>"]},
                ['blocking']
    );
    